# World Class.corp_Restaurant-KTT-G20

## Deskripsi

Program ini merupakan program simulasi untuk pemesanan di sebuah restaurant secara self service. Dimana pelanggan akan
memasan makanan dan minuman sendiri melalui aplikasi ini. Setelah mengikuti step by step akan muncul struk pembayaran
yang di bayar ditempar kasir.

## Anggota Kelompok

Ketua :

- Rachmat Fajar

Anggota :

- Alifan Naufally Atha
- Muhammad Danish Rabbani
- Muhammad Ichsan
- Rizka Nawatul Azka

## Cara Run Program

1. Clone/Download Repository Github ini
2. Selanjutnya buka dan extrak folder zip
3. buka folder Projek_Lab_PBO.jar dengan menggunakan IDE
4. Buka IDE ,menambahkan folder yang ingin di tuju
5. Jika ingin di jalankan secara manual, maka buka file Main dan click Run
6. jika ingin langsung menjalankan dari folder yang ada pada file manager,
   maka langsung klik file berekstensi .jar
   maka program gui langsung di jalankan secara otomatis

## Disclaimer

Program dibangun Menggunakan JDK-18. Sehingga apabila terdapat error, silakan mencoba
menjalankan dengan menggunakan JDK-18.
