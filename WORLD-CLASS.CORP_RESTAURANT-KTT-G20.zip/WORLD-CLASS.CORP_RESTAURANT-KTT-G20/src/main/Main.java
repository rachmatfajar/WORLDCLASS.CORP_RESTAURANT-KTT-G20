
package main;

import GUI.MenuGUI;

public class Main {

    public static void main(String[] args) {
        MenuGUI tes = new MenuGUI();
        tes.setVisible(true);
    }
    
}
